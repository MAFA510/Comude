package com.example.comude

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.TelephonyCallback
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.ktx.Firebase
import com.google.firebase.ktx.app




        class AuthActivity : AppCompatActivity() {
            private lateinit var firebaseAuth: FirebaseAuth
            private lateinit var authStateListener: FirebaseAuth.AuthStateListener


            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContentView(R.layout.activity_main)

                val btningresar: Button = findViewById(R.id.btnIniciar)
                val txtemail: TextView = findViewById(R.id.txtEmail)
                val txtpass: TextView = findViewById(R.id.txtPassword)
                firebaseAuth=Firebase.auth
                btningresar.setOnClickListener()
                {
                    singIn(txtemail.text.toString(), txtpass.text.toString())
                }


                //Boton de Registro
                val btn2: Button = findViewById(R.id.singUpbutton)
                btn2.setOnClickListener {

                    val btn2: Intent = Intent(this, RegisterActivity::class.java)
                    startActivity(btn2)
                }
            }

            private fun singIn(email: String, password: String) {
                firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            val user = firebaseAuth.currentUser
                            Toast.makeText(baseContext, user?.uid.toString(), Toast.LENGTH_SHORT)
                                .show()
                            //Eviar a Pagina Principal
                        } else {
                            Toast.makeText(
                                baseContext,
                                "Error de Email y/o Contraseña",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
            }
        }






/**
//val authUser: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
fun goTo(){
if(authUser.currentUser != null){
startActivity(Intent(this, ActivitySplash::class.java))
finish()
}else{
startActivity(Intent(this, RegisterActivity::class.java))
finish()
}
}*/





/**
//Sistema de Autenticacion
setup()
}
private fun setup() {

title = "Autenticacion"

signUpbutton.setOnClickListener {
if (emailEditText.text.isNotEmpty() && passwordEditText.Text.isNotEmpty()) {

FirebaseAuth.getInstance()
.createUserWithEmailAndPassword(
emailEditText.text.toString(),
passwordEditText.text.toString()
).addOnCompleteListener {

if (it.isSuccessful) {

} else {
showAlert()
}
}
}
}
}
private fun showAlert() {

val builder = AlertDialog.Builder()
builder.setTitle("Error")
builder.setMessage("Se ha producido un error autenticando al usuario")
builder.setPositiveButton(text:"Aceptar", listener: null)
val dialog: AlertDialog = builder.create()
dialog.Show()
}
 */